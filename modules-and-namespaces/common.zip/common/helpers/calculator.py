# calculator.py

__all__ = ['Calc']

class Calc:
    pass

def helper_function():
    print("Helper function")

def private_helper_function():
    print("Private helper function")